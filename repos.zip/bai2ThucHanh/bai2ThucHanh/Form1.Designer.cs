﻿namespace bai2ThucHanh
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lbYeuCau = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.rdoFrance = new System.Windows.Forms.RadioButton();
            this.rdoJapan = new System.Windows.Forms.RadioButton();
            this.rdoHungary = new System.Windows.Forms.RadioButton();
            this.Spain = new System.Windows.Forms.RadioButton();
            this.rdoTurkey = new System.Windows.Forms.RadioButton();
            this.rdoUK = new System.Windows.Forms.RadioButton();
            this.rdoItalia = new System.Windows.Forms.RadioButton();
            this.rdoArgentina = new System.Windows.Forms.RadioButton();
            this.rdoBrazil = new System.Windows.Forms.RadioButton();
            this.rdoUSA = new System.Windows.Forms.RadioButton();
            this.rdoAires = new System.Windows.Forms.RadioButton();
            this.rdoBrazilCap = new System.Windows.Forms.RadioButton();
            this.rdoTokyo = new System.Windows.Forms.RadioButton();
            this.rdoRome = new System.Windows.Forms.RadioButton();
            this.rdoWashington = new System.Windows.Forms.RadioButton();
            this.rdoMadrid = new System.Windows.Forms.RadioButton();
            this.rdoLondon = new System.Windows.Forms.RadioButton();
            this.rdoAnkara = new System.Windows.Forms.RadioButton();
            this.rdoBudapest = new System.Windows.Forms.RadioButton();
            this.rdoParis = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdoUSA);
            this.groupBox1.Controls.Add(this.rdoBrazil);
            this.groupBox1.Controls.Add(this.rdoArgentina);
            this.groupBox1.Controls.Add(this.rdoItalia);
            this.groupBox1.Controls.Add(this.rdoUK);
            this.groupBox1.Controls.Add(this.rdoTurkey);
            this.groupBox1.Controls.Add(this.Spain);
            this.groupBox1.Controls.Add(this.rdoHungary);
            this.groupBox1.Controls.Add(this.rdoJapan);
            this.groupBox1.Controls.Add(this.rdoFrance);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(194, 275);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Country";
            this.groupBox1.Enter += new System.EventHandler(this.GroupBox1_Enter);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rdoParis);
            this.groupBox2.Controls.Add(this.rdoBudapest);
            this.groupBox2.Controls.Add(this.rdoAnkara);
            this.groupBox2.Controls.Add(this.rdoLondon);
            this.groupBox2.Controls.Add(this.rdoMadrid);
            this.groupBox2.Controls.Add(this.rdoWashington);
            this.groupBox2.Controls.Add(this.rdoRome);
            this.groupBox2.Controls.Add(this.rdoTokyo);
            this.groupBox2.Controls.Add(this.rdoBrazilCap);
            this.groupBox2.Controls.Add(this.rdoAires);
            this.groupBox2.Location = new System.Drawing.Point(243, 13);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(194, 275);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Capital";
            // 
            // lbYeuCau
            // 
            this.lbYeuCau.AutoSize = true;
            this.lbYeuCau.Location = new System.Drawing.Point(10, 300);
            this.lbYeuCau.Name = "lbYeuCau";
            this.lbYeuCau.Size = new System.Drawing.Size(0, 13);
            this.lbYeuCau.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(362, 300);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "Thoát";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // rdoFrance
            // 
            this.rdoFrance.AutoSize = true;
            this.rdoFrance.Location = new System.Drawing.Point(23, 30);
            this.rdoFrance.Name = "rdoFrance";
            this.rdoFrance.Size = new System.Drawing.Size(58, 17);
            this.rdoFrance.TabIndex = 0;
            this.rdoFrance.TabStop = true;
            this.rdoFrance.Text = "France";
            this.rdoFrance.UseVisualStyleBackColor = true;
            this.rdoFrance.CheckedChanged += new System.EventHandler(this.RdoFrance_CheckedChanged);
            // 
            // rdoJapan
            // 
            this.rdoJapan.AutoSize = true;
            this.rdoJapan.Location = new System.Drawing.Point(23, 53);
            this.rdoJapan.Name = "rdoJapan";
            this.rdoJapan.Size = new System.Drawing.Size(54, 17);
            this.rdoJapan.TabIndex = 1;
            this.rdoJapan.TabStop = true;
            this.rdoJapan.Text = "Japan";
            this.rdoJapan.UseVisualStyleBackColor = true;
            this.rdoJapan.CheckedChanged += new System.EventHandler(this.RdoJapan_CheckedChanged);
            // 
            // rdoHungary
            // 
            this.rdoHungary.AutoSize = true;
            this.rdoHungary.Location = new System.Drawing.Point(23, 76);
            this.rdoHungary.Name = "rdoHungary";
            this.rdoHungary.Size = new System.Drawing.Size(65, 17);
            this.rdoHungary.TabIndex = 2;
            this.rdoHungary.TabStop = true;
            this.rdoHungary.Text = "Hungary";
            this.rdoHungary.UseVisualStyleBackColor = true;
            this.rdoHungary.CheckedChanged += new System.EventHandler(this.RdoHungary_CheckedChanged);
            // 
            // Spain
            // 
            this.Spain.AutoSize = true;
            this.Spain.Location = new System.Drawing.Point(23, 99);
            this.Spain.Name = "Spain";
            this.Spain.Size = new System.Drawing.Size(52, 17);
            this.Spain.TabIndex = 3;
            this.Spain.TabStop = true;
            this.Spain.Text = "Spain";
            this.Spain.UseVisualStyleBackColor = true;
            this.Spain.CheckedChanged += new System.EventHandler(this.Spain_CheckedChanged);
            // 
            // rdoTurkey
            // 
            this.rdoTurkey.AutoSize = true;
            this.rdoTurkey.Location = new System.Drawing.Point(23, 122);
            this.rdoTurkey.Name = "rdoTurkey";
            this.rdoTurkey.Size = new System.Drawing.Size(58, 17);
            this.rdoTurkey.TabIndex = 4;
            this.rdoTurkey.TabStop = true;
            this.rdoTurkey.Text = "Turkey";
            this.rdoTurkey.UseVisualStyleBackColor = true;
            this.rdoTurkey.CheckedChanged += new System.EventHandler(this.RdoTurkey_CheckedChanged);
            // 
            // rdoUK
            // 
            this.rdoUK.AutoSize = true;
            this.rdoUK.Location = new System.Drawing.Point(23, 145);
            this.rdoUK.Name = "rdoUK";
            this.rdoUK.Size = new System.Drawing.Size(62, 17);
            this.rdoUK.TabIndex = 5;
            this.rdoUK.TabStop = true;
            this.rdoUK.Text = "The UK";
            this.rdoUK.UseVisualStyleBackColor = true;
            this.rdoUK.CheckedChanged += new System.EventHandler(this.RdoUK_CheckedChanged);
            // 
            // rdoItalia
            // 
            this.rdoItalia.AutoSize = true;
            this.rdoItalia.Location = new System.Drawing.Point(23, 168);
            this.rdoItalia.Name = "rdoItalia";
            this.rdoItalia.Size = new System.Drawing.Size(47, 17);
            this.rdoItalia.TabIndex = 6;
            this.rdoItalia.TabStop = true;
            this.rdoItalia.Text = "Italia";
            this.rdoItalia.UseVisualStyleBackColor = true;
            this.rdoItalia.CheckedChanged += new System.EventHandler(this.RdoItalia_CheckedChanged);
            // 
            // rdoArgentina
            // 
            this.rdoArgentina.AutoSize = true;
            this.rdoArgentina.Location = new System.Drawing.Point(23, 191);
            this.rdoArgentina.Name = "rdoArgentina";
            this.rdoArgentina.Size = new System.Drawing.Size(70, 17);
            this.rdoArgentina.TabIndex = 7;
            this.rdoArgentina.TabStop = true;
            this.rdoArgentina.Text = "Argentina";
            this.rdoArgentina.UseVisualStyleBackColor = true;
            this.rdoArgentina.CheckedChanged += new System.EventHandler(this.RdoArgentina_CheckedChanged);
            // 
            // rdoBrazil
            // 
            this.rdoBrazil.AutoSize = true;
            this.rdoBrazil.Location = new System.Drawing.Point(23, 214);
            this.rdoBrazil.Name = "rdoBrazil";
            this.rdoBrazil.Size = new System.Drawing.Size(50, 17);
            this.rdoBrazil.TabIndex = 8;
            this.rdoBrazil.TabStop = true;
            this.rdoBrazil.Text = "Brazil";
            this.rdoBrazil.UseVisualStyleBackColor = true;
            this.rdoBrazil.CheckedChanged += new System.EventHandler(this.RdoBrazil_CheckedChanged);
            // 
            // rdoUSA
            // 
            this.rdoUSA.AutoSize = true;
            this.rdoUSA.Location = new System.Drawing.Point(23, 235);
            this.rdoUSA.Name = "rdoUSA";
            this.rdoUSA.Size = new System.Drawing.Size(69, 17);
            this.rdoUSA.TabIndex = 9;
            this.rdoUSA.TabStop = true;
            this.rdoUSA.Text = "The USA";
            this.rdoUSA.UseVisualStyleBackColor = true;
            this.rdoUSA.CheckedChanged += new System.EventHandler(this.RdoUSA_CheckedChanged);
            // 
            // rdoAires
            // 
            this.rdoAires.AutoSize = true;
            this.rdoAires.Location = new System.Drawing.Point(24, 30);
            this.rdoAires.Name = "rdoAires";
            this.rdoAires.Size = new System.Drawing.Size(87, 17);
            this.rdoAires.TabIndex = 0;
            this.rdoAires.TabStop = true;
            this.rdoAires.Text = "Beunos Aires";
            this.rdoAires.UseVisualStyleBackColor = true;
            this.rdoAires.CheckedChanged += new System.EventHandler(this.RdoAires_CheckedChanged);
            // 
            // rdoBrazilCap
            // 
            this.rdoBrazilCap.AutoSize = true;
            this.rdoBrazilCap.Location = new System.Drawing.Point(24, 53);
            this.rdoBrazilCap.Name = "rdoBrazilCap";
            this.rdoBrazilCap.Size = new System.Drawing.Size(50, 17);
            this.rdoBrazilCap.TabIndex = 1;
            this.rdoBrazilCap.TabStop = true;
            this.rdoBrazilCap.Text = "Brazil";
            this.rdoBrazilCap.UseVisualStyleBackColor = true;
            this.rdoBrazilCap.CheckedChanged += new System.EventHandler(this.RdoBrazilCap_CheckedChanged);
            // 
            // rdoTokyo
            // 
            this.rdoTokyo.AutoSize = true;
            this.rdoTokyo.Location = new System.Drawing.Point(24, 76);
            this.rdoTokyo.Name = "rdoTokyo";
            this.rdoTokyo.Size = new System.Drawing.Size(55, 17);
            this.rdoTokyo.TabIndex = 2;
            this.rdoTokyo.TabStop = true;
            this.rdoTokyo.Text = "Tokyo";
            this.rdoTokyo.UseVisualStyleBackColor = true;
            this.rdoTokyo.CheckedChanged += new System.EventHandler(this.RdoTokyo_CheckedChanged);
            // 
            // rdoRome
            // 
            this.rdoRome.AutoSize = true;
            this.rdoRome.Location = new System.Drawing.Point(24, 99);
            this.rdoRome.Name = "rdoRome";
            this.rdoRome.Size = new System.Drawing.Size(53, 17);
            this.rdoRome.TabIndex = 3;
            this.rdoRome.TabStop = true;
            this.rdoRome.Text = "Rome";
            this.rdoRome.UseVisualStyleBackColor = true;
            this.rdoRome.CheckedChanged += new System.EventHandler(this.RdoRome_CheckedChanged);
            // 
            // rdoWashington
            // 
            this.rdoWashington.AutoSize = true;
            this.rdoWashington.Location = new System.Drawing.Point(24, 122);
            this.rdoWashington.Name = "rdoWashington";
            this.rdoWashington.Size = new System.Drawing.Size(82, 17);
            this.rdoWashington.TabIndex = 4;
            this.rdoWashington.TabStop = true;
            this.rdoWashington.Text = "Washington";
            this.rdoWashington.UseVisualStyleBackColor = true;
            this.rdoWashington.CheckedChanged += new System.EventHandler(this.RdoWashington_CheckedChanged);
            // 
            // rdoMadrid
            // 
            this.rdoMadrid.AutoSize = true;
            this.rdoMadrid.Location = new System.Drawing.Point(24, 145);
            this.rdoMadrid.Name = "rdoMadrid";
            this.rdoMadrid.Size = new System.Drawing.Size(57, 17);
            this.rdoMadrid.TabIndex = 5;
            this.rdoMadrid.TabStop = true;
            this.rdoMadrid.Text = "Madrid";
            this.rdoMadrid.UseVisualStyleBackColor = true;
            this.rdoMadrid.CheckedChanged += new System.EventHandler(this.RdoMadrid_CheckedChanged);
            // 
            // rdoLondon
            // 
            this.rdoLondon.AutoSize = true;
            this.rdoLondon.Location = new System.Drawing.Point(24, 168);
            this.rdoLondon.Name = "rdoLondon";
            this.rdoLondon.Size = new System.Drawing.Size(61, 17);
            this.rdoLondon.TabIndex = 6;
            this.rdoLondon.TabStop = true;
            this.rdoLondon.Text = "London";
            this.rdoLondon.UseVisualStyleBackColor = true;
            this.rdoLondon.CheckedChanged += new System.EventHandler(this.RdoLondon_CheckedChanged);
            // 
            // rdoAnkara
            // 
            this.rdoAnkara.AutoSize = true;
            this.rdoAnkara.Location = new System.Drawing.Point(24, 191);
            this.rdoAnkara.Name = "rdoAnkara";
            this.rdoAnkara.Size = new System.Drawing.Size(59, 17);
            this.rdoAnkara.TabIndex = 7;
            this.rdoAnkara.TabStop = true;
            this.rdoAnkara.Text = "Ankara";
            this.rdoAnkara.UseVisualStyleBackColor = true;
            this.rdoAnkara.CheckedChanged += new System.EventHandler(this.RdoAnkara_CheckedChanged);
            // 
            // rdoBudapest
            // 
            this.rdoBudapest.AutoSize = true;
            this.rdoBudapest.Location = new System.Drawing.Point(24, 214);
            this.rdoBudapest.Name = "rdoBudapest";
            this.rdoBudapest.Size = new System.Drawing.Size(70, 17);
            this.rdoBudapest.TabIndex = 8;
            this.rdoBudapest.TabStop = true;
            this.rdoBudapest.Text = "Budapest";
            this.rdoBudapest.UseVisualStyleBackColor = true;
            this.rdoBudapest.CheckedChanged += new System.EventHandler(this.RdoBudapest_CheckedChanged);
            // 
            // rdoParis
            // 
            this.rdoParis.AutoSize = true;
            this.rdoParis.Location = new System.Drawing.Point(24, 235);
            this.rdoParis.Name = "rdoParis";
            this.rdoParis.Size = new System.Drawing.Size(48, 17);
            this.rdoParis.TabIndex = 9;
            this.rdoParis.TabStop = true;
            this.rdoParis.Text = "Paris";
            this.rdoParis.UseVisualStyleBackColor = true;
            this.rdoParis.CheckedChanged += new System.EventHandler(this.RdoParis_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(448, 335);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbYeuCau);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Capital of Country";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdoUSA;
        private System.Windows.Forms.RadioButton rdoBrazil;
        private System.Windows.Forms.RadioButton rdoArgentina;
        private System.Windows.Forms.RadioButton rdoItalia;
        private System.Windows.Forms.RadioButton rdoUK;
        private System.Windows.Forms.RadioButton rdoTurkey;
        private System.Windows.Forms.RadioButton Spain;
        private System.Windows.Forms.RadioButton rdoHungary;
        private System.Windows.Forms.RadioButton rdoJapan;
        private System.Windows.Forms.RadioButton rdoFrance;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rdoParis;
        private System.Windows.Forms.RadioButton rdoBudapest;
        private System.Windows.Forms.RadioButton rdoAnkara;
        private System.Windows.Forms.RadioButton rdoLondon;
        private System.Windows.Forms.RadioButton rdoMadrid;
        private System.Windows.Forms.RadioButton rdoWashington;
        private System.Windows.Forms.RadioButton rdoRome;
        private System.Windows.Forms.RadioButton rdoTokyo;
        private System.Windows.Forms.RadioButton rdoBrazilCap;
        private System.Windows.Forms.RadioButton rdoAires;
        private System.Windows.Forms.Label lbYeuCau;
        private System.Windows.Forms.Button button1;
    }
}

